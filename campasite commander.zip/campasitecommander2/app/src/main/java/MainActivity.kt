import android.R
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.delay

// Nature-Themed Palette
val ForestDark = Color(0xFF1B2E1F)
val Sage = Color(0xFF8DA47E)
val EarthyBrown = Color(0xFF3E2723)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Sage,
                    background = ForestDark,
                    surface = Color(0xFF253328)
                )
            ) {
                CampsiteApp()
            }
        }
    }
}

@Composable
fun CampsiteApp() {
    val navController = rememberNavController()

    // --- DATA STORAGE: PARALLEL ARRAYS ---
    // Initializing with sample data
    var itemNames by remember { mutableStateOf(arrayOf("Tent", "Sleeping Bag", "Flashlight")) }
    var itemCategories by remember { mutableStateOf(arrayOf("Shelter", "Bedding", "Tools")) }
    var itemQuantities by remember { mutableStateOf(arrayOf(1, 2, 4)) }

    // Function to add item to parallel arrays
    fun addGearItem(name: String, category: String, qty: Int) {
        itemNames += name
        itemCategories += category
        itemQuantities += qty
    }

    // Function to delete item from parallel arrays
    fun deleteGearItem(index: Int) {
        itemNames = itemNames.filterIndexed { i, _ -> i != index }.toTypedArray()
        itemCategories = itemCategories.filterIndexed { i, _ -> i != index }.toTypedArray()
        itemQuantities = itemQuantities.filterIndexed { i, _ -> i != index }.toTypedArray()
    }

    NavHost(navController = navController, startDestination = "splash") {
        composable("splash") {
                navController.navigate("main") {
                    popUpTo("splash") { inclusive = true }
                }
            })
        }

        composable("main") {
            MainGearScreen(
                names = itemNames,
                categories = itemCategories,
                quantities = itemQuantities,
                onNavigateToAdd = { navController.navigate("add") },
                onDelete = { index -> deleteGearItem(index) }
            )
        }

        composable("add") {
            AddGearScreen(
                onAddItem = { name, cat, qty ->
                    addGearItem(name, cat, qty)
                    navController.popBackStack()
                },
                onBack = { navController.popBackStack() }
            )
        }
    }
}

@Composable
fun SplashScreen(onTimeout: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(3000L) // 3 Seconds
        onTimeout()
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ForestDark),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                painter = painterResource(id = R.drawable.ic_menu_compass),
                contentDescription = "Logo",
                modifier = Modifier.size(120.dp),
                tint = Sage
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                "CAMPSITE COMMANDER",
                fontWeight = FontWeight.Bold,
                color = Color.White,
                fontSize = 24.sp
            )
            Text("Ready for Adventure", color = Sage)
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainGearScreen(
    names: Array<String>,
    categories: Array<String>,
    quantities: Array<Int>,
    onNavigateToAdd: () -> Unit,
    onDelete: (Int) -> Unit
) {
    // --- LOOP CALCULATION ---
    // Calculating total items packed effectively using a loop through the quantity array
    var totalItemsCount = 0
    for (i in quantities.indices) {
        totalItemsCount += quantities[i]
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("COMMAND CENTER") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ForestDark,
                    titleContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onNavigateToAdd, containerColor = Sage) {
                Icon(Icons.Default.Add, contentDescription = "Add", tint = ForestDark)
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .padding(padding)
                .fillMaxSize()
                .background(ForestDark)
                .padding(16.dp)
        ) {

            // Visual Counter Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF2C3E2F)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.CheckCircle,
                        null,
                        tint = Sage,
                        modifier = Modifier.size(40.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            "TOTAL ITEMS PACKED",
                            style = MaterialTheme.typography.labelMedium,
                            color = Sage
                        )
                        Text(
                            "$totalItemsCount",
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            LazyColumn {
                // Using indices to navigate parallel arrays
                items(names.size) { index ->
                    GearListItem(
                        name = names[index],
                        category = categories[index],
                        quantity = quantities[index],
                        onDelete = { onDelete(index) }
                    )
                }
            }
        }
    }
}

@Composable
fun GearListItem(name: String, category: String, quantity: Int, onDelete: () -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF344437))
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Column {
                Text(name, color = Color.White, fontSize = 18.sp, fontWeight = FontWeight.Bold)
                Text("$category • Qty: $quantity", color = Sage, fontSize = 14.sp)
            }
            IconButton(onClick = onDelete) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF9A9A))
            }
        }
    }
}

@Composable
fun AddGearScreen(onAddItem: (String, String, Int) -> Unit, onBack: () -> Unit) {
    var name by remember { mutableStateOf("") }
    var category by remember { mutableStateOf("") }
    var quantity by remember { mutableStateOf("1") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ForestDark)
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Pack New Gear", color = Color.White, style = MaterialTheme.typography.headlineSmall)
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Item Name") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = category,
            onValueChange = { category = it },
            label = { Text("Category") },
            modifier = Modifier.fillMaxWidth()
        )
        OutlinedTextField(
            value = quantity,
            onValueChange = { quantity = it },
            label = { Text("Quantity") },
            modifier = Modifier.fillMaxWidth()
        )

        Spacer(modifier = Modifier.height(24.dp))
        Button(
            onClick = {
                val q = quantity.toIntOrNull() ?: 1
                if (name.isNotBlank()) onAddItem(name, category, q)
            },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Sage)
        ) {
            Text("CONFIRM PACK", color = ForestDark)
        }
        TextButton(onClick = onBack, modifier = Modifier.align(Alignment.CenterHorizontally)) {
            Text("Cancel", color = Color.Gray)
        }
    }
}