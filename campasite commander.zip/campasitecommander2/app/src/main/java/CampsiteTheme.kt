import android.R
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import kotlinx.coroutines.delay

// Data Model
data class GearItem(val id: Int, val name: String, val isPacked: Boolean)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CampsiteTheme {
                GearApp()
            }
        }
    }
}

@Composable
fun CampsiteTheme(content: @Composable () -> Unit) {
    val natureColorScheme = darkColorScheme(
        primary = Color(0xFF81C784), // Moss Green
        secondary = Color(0xFFD7CCC8), // Wood Brown
        background = Color(0xFF1B3022), // Dark Forest
        surface = Color(0xFF2E3D32),
        onPrimary = Color(0xFF1B3022)
    )
    MaterialTheme(colorScheme = natureColorScheme, content = content)
}

@Composable
fun GearApp() {
    val navController = rememberNavController()
    val gearList = remember { mutableStateListOf<GearItem>() }

    NavHost(navController = navController, startDestination = "splash") {
        composable("splash") {
            androidx.core.splashscreen.SplashScreen {
                navController.navigate("main") {
                    popUpTo("splash") {
                        inclusive = true
                    }
                }
            }
        }
        composable("main") {
            MainScreen(
                items = gearList,
                onAddClick = { navController.navigate("add") },
                onDeleteItem = { gearList.remove(it) }
            )
        }
        composable("add") {
            AddGearScreen(
                onAdd = { name ->
                    gearList.add(GearItem(gearList.size, name, true))
                    navController.popBackStack()
                },
                onBack = { navController.popBackStack() }
            )
        }
    }
}

@Composable
fun MainScreen(items: List<GearItem>, onAddClick: () -> Unit, onDeleteItem: (GearItem) -> Unit) {
    // Logic: Calculate total items packed using a loop as requested
    var totalPacked = 0
    for (item in items) {
        if (item.isPacked) {
            totalPacked++
        }
    }

    Scaffold(
        topBar = {
            CenterAlignedTopAppBar(
                title = { Text("CAMPSITE COMMANDER", fontWeight = FontWeight.Bold) },
                colors = TopAppBarDefaults.centerAlignedTopAppBarColors(
                    containerColor = Color(0xFF1B5E20)
                )
            )
        },
        floatingActionButton = {
            LargeFloatingActionButton(
                onClick = onAddClick,
                containerColor = MaterialTheme.colorScheme.primary
            ) {
                Icon(
                    Icons.Default.Add,
                    contentDescription = "Add Gear",
                    modifier = Modifier.size(36.dp)
                )
            }
        }
    ) { padding ->
        Column(
            modifier = Modifier
                .fillMaxSize()
                .padding(padding)
                .background(MaterialTheme.colorScheme.background)
                .padding(16.dp),
            horizontalAlignment = Alignment.CenterHorizontally
        ) {
            // Stats Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = MaterialTheme.colorScheme.surface),
                shape = RoundedCornerShape(16.dp)
            ) {
                Column(
                    modifier = Modifier.padding(24.dp),
                    horizontalAlignment = Alignment.CenterHorizontally
                ) {
                    Icon(
                        Icons.Default.CheckCircle,
                        contentDescription = null,
                        tint = MaterialTheme.colorScheme.primary,
                        modifier = Modifier.size(48.dp)
                    )
                    Text("Inventory Status", style = MaterialTheme.typography.labelLarge)
                    Text(
                        text = "$totalPacked Items Ready",
                        style = MaterialTheme.typography.headlineMedium,
                        color = MaterialTheme.colorScheme.primary,
                        fontWeight = FontWeight.ExtraBold
                    )
                }
            }

            Spacer(modifier = Modifier.height(24.dp))

            Text("GEAR LIST", style = MaterialTheme.typography.titleSmall, color = Color.Gray)

            LazyColumn(modifier = Modifier.fillMaxSize()) {
                items(items) { item ->
                    GearRow(item, onDeleteItem)
                }
            }
        }
    }
}

@Composable
fun GearRow(item: GearItem, onDelete: (GearItem) -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF38493D))
    ) {
        Row(
            modifier = Modifier.padding(16.dp),
            verticalAlignment = Alignment.CenterVertically,
            horizontalArrangement = Arrangement.SpaceBetween
        ) {
            Text(item.name, color = Color.White, fontSize = 18.sp)
            IconButton(onClick = { onDelete(item) }) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF9A9A))
            }
        }
    }
}

@Composable
fun SplashScreen(onTimeout: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(3000L)
        onTimeout()
    }
    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1B3022)),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            Icon(
                painterResource(R.drawable.ic_menu_compass),
                "Logo",
                Modifier.size(100.dp),
                tint = Color(0xFF81C784)
            )
            Text(
                "CAMPSITE COMMANDER",
                color = Color.White,
                fontWeight = FontWeight.Bold,
                fontSize = 24.sp
            )
        }
    }
}

@Composable
fun AddGearScreen(onAdd: (String) -> Unit, onBack: () -> Unit) {
    var text by remember { mutableStateOf("") }
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(Color(0xFF1B3022))
            .padding(32.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text("Add New Gear", style = MaterialTheme.typography.headlineMedium, color = Color.White)
        OutlinedTextField(
            value = text,
            onValueChange = { text = it },
            label = { Text("Item Name") },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(focusedBorderColor = Color(0xFF81C784))
        )
        Spacer(modifier = Modifier.height(16.dp))
        Button(
            onClick = { if (text.isNotBlank()) onAdd(text) },
            modifier = Modifier.fillMaxWidth()
        ) {
            Text("PACK IT")
        }
        TextButton(onClick = onBack, modifier = Modifier.fillMaxWidth()) {
            Text("Cancel", color = Color.Gray)
        }
    }
}