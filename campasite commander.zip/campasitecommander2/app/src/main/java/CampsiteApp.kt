import android.R
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.foundation.shape.RoundedCornerShape
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.CheckCircle
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material.icons.filled.Place
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.campasitecommander.ui.theme.CampasiteCommanderTheme
import kotlinx.coroutines.delay

// Nature-Themed Color Palette
val ForestDark = Color(0xFF1B2E1F)
val MossGreen = Color(0xFF4E6B3E)
val EarthBrown = Color(0xFF3E2723)
val Sage = Color(0xFF8DA47E)

data class GearItem(val id: Int, val name: String, val isPacked: Boolean = true)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            // Applying a custom dark nature theme
            MaterialTheme(
                colorScheme = darkColorScheme(
                    primary = Sage,
                    background = ForestDark,
                    surface = Color(0xFF253328)
                )
            ) {
                CampsiteApp()
            }
        }
    }
}

@Composable
fun CampsiteApp() {
    val navController = rememberNavController()
    val gearItems = remember { mutableStateListOf<GearItem>() }

    NavHost(navController = navController, startDestination = "splash") {
        composable("splash") {
            androidx.core.splashscreen.SplashScreen(onTimeout = {
                navController.navigate("main") {
                    popUpTo("splash") { inclusive = true }
                }
            })
        }

        composable("main") {
            MainGearScreen(
                items = gearItems,
                onNavigateToAdd = { navController.navigate("add") },
                onDeleteItem = { item -> gearItems.remove(item) }
            )
        }

        composable("add") {
            AddGearScreen(
                onAddItem = { name ->
                    gearItems.add(GearItem(id = gearItems.size, name = name))
                    navController.popBackStack()
                },
                onBack = { navController.popBackStack() }
            )
        }
    }
}

@Composable
fun SplashScreen(onTimeout: () -> Unit) {
    LaunchedEffect(Unit) {
        delay(3000L) // 3 seconds delay
        onTimeout()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(ForestDark),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            // Using a standard Android icon as a placeholder for a Pine Tree
            Icon(
                painter = painterResource(id = R.drawable.ic_menu_compass),
                contentDescription = "Logo",
                modifier = Modifier.size(120.dp),
                tint = Sage
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "CAMPSITE COMMANDER",
                style = MaterialTheme.typography.headlineMedium,
                fontWeight = FontWeight.Bold,
                color = Color.White,
                letterSpacing = 2.sp
            )
            Text(
                text = "Ready for Adventure",
                style = MaterialTheme.typography.bodyMedium,
                color = Sage
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun MainGearScreen(
    items: List<GearItem>,
    onNavigateToAdd: () -> Unit,
    onDeleteItem: (GearItem) -> Unit
) {
    // LOOP LOGIC: Calculate total items packed
    var totalPacked = 0
    for (item in items) {
        if (item.isPacked) {
            totalPacked++
        }
    }

    Scaffold(
        topBar = {
            TopAppBar(
                title = { Text("COMMAND CENTER") },
                colors = TopAppBarDefaults.topAppBarColors(
                    containerColor = ForestDark,
                    titleContentColor = Color.White
                )
            )
        },
        floatingActionButton = {
            FloatingActionButton(onClick = onNavigateToAdd, containerColor = Sage) {
                Icon(Icons.Default.Add, contentDescription = "Add Gear", tint = ForestDark)
            }
        }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()
                .background(ForestDark)
                .padding(16.dp)
        ) {
            // Visual Counter Card
            Card(
                modifier = Modifier.fillMaxWidth(),
                colors = CardDefaults.cardColors(containerColor = Color(0xFF2C3E2F)),
                shape = RoundedCornerShape(16.dp)
            ) {
                Row(
                    modifier = Modifier.padding(20.dp),
                    verticalAlignment = Alignment.CenterVertically
                ) {
                    Icon(
                        Icons.Default.CheckCircle,
                        "Packed",
                        tint = Sage,
                        modifier = Modifier.size(40.dp)
                    )
                    Spacer(modifier = Modifier.width(16.dp))
                    Column {
                        Text(
                            "TOTAL GEAR PACKED",
                            style = MaterialTheme.typography.labelMedium,
                            color = Sage
                        )
                        Text(
                            text = "$totalPacked Items",
                            style = MaterialTheme.typography.headlineLarge,
                            fontWeight = FontWeight.Black,
                            color = Color.White
                        )
                    }
                }
            }

            Spacer(modifier = Modifier.height(20.dp))

            if (items.isEmpty()) {
                Box(Modifier.fillMaxSize(), contentAlignment = Alignment.Center) {
                    Text("Your gear list is empty.", color = Color.Gray)
                }
            } else {
                LazyColumn {
                    items(items) { item ->
                        GearListItem(item, onDeleteItem)
                    }
                }
            }
        }
    }
}

@Composable
fun GearListItem(item: GearItem, onDeleteItem: (GearItem) -> Unit) {
    Card(
        modifier = Modifier
            .fillMaxWidth()
            .padding(vertical = 4.dp),
        colors = CardDefaults.cardColors(containerColor = Color(0xFF344437))
    ) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Text(text = item.name, color = Color.White, fontSize = 18.sp)
            IconButton(onClick = { onDeleteItem(item) }) {
                Icon(Icons.Default.Delete, contentDescription = "Delete", tint = Color(0xFFEF9A9A))
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddGearScreen(onAddItem: (String) -> Unit, onBack: () -> Unit) {
    var gearName by remember { mutableStateOf("") }

    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(ForestDark)
            .padding(24.dp),
        verticalArrangement = Arrangement.Center
    ) {
        Text(
            "What are we packing?",
            color = Color.White,
            style = MaterialTheme.typography.headlineSmall
        )
        Spacer(modifier = Modifier.height(16.dp))
        OutlinedTextField(
            value = gearName,
            onValueChange = { gearName = it },
            label = { Text("Gear Name") },
            modifier = Modifier.fillMaxWidth(),
            colors = OutlinedTextFieldDefaults.colors(
                focusedBorderColor = Sage,
                unfocusedBorderColor = Color.Gray,
                focusedLabelColor = Sage
            )
        )
        Spacer(modifier = Modifier.height(24.dp))
        Button(
            onClick = { if (gearName.isNotBlank()) onAddItem(gearName) },
            modifier = Modifier.fillMaxWidth(),
            colors = ButtonDefaults.buttonColors(containerColor = Sage)
        ) {
            Text("ADD TO PACK", color = ForestDark, fontWeight = FontWeight.Bold)
        }
        TextButton(onClick = onBack, modifier = Modifier.align(Alignment.CenterHorizontally)) {
            Text("Cancel", color = Color.Gray)
        }
    }
}