import android.R
import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.campasitecommander.ui.theme.CampasiteCommanderTheme
import kotlinx.coroutines.delay

// Data model for Grocery Item
data class GroceryItem(val id: Int, val name: String, val category: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CampasiteCommanderTheme {
                GroceryApp()
            }
        }
    }
}

@Composable
fun GroceryApp() {
    val navController = rememberNavController()
    val groceryItems = remember { mutableStateListOf<GroceryItem>() }
    val categories = arrayOf("Produce", "Dairy", "Bakery", "Frozen", "Other")

    NavHost(navController = navController, startDestination = "splash") {
        // Splash Screen Route
        composable("splash") {
            SplashScreen(onTimeout = {
                navController.navigate("list") {
                    // Pop splash from backstack so back button doesn't return to it
                    popUpTo("splash") { inclusive = true }
                }
            })
        }

        composable("list") {
            GroceryListScreen(
                items = groceryItems,
                onNavigateToAdd = { navController.navigate("add") },
                onDeleteItem = { item -> groceryItems.remove(item) }
            )
        }
        composable("add") {
            AddGroceryScreen(
                categories = categories,
                onAddItem = { name, category ->
                    val newItem =
                        GroceryItem(id = groceryItems.size, name = name, category = category)
                    groceryItems.add(newItem)
                    navController.popBackStack()
                },
                onBack = { navController.popBackStack() }
            )
        }
    }
}

@Composable
fun SplashScreen(onTimeout: () -> Unit) {
    // LaunchedEffect runs the block once when the composable enters the composition
    LaunchedEffect(Unit) {
        delay(3000L) // 3000 milliseconds = 3 seconds
        onTimeout()
    }

    Box(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colorScheme.primaryContainer),
        contentAlignment = Alignment.Center
    ) {
        Column(horizontalAlignment = Alignment.CenterHorizontally) {
            // Replace 'ic_launcher_foreground' with your actual logo resource ID
            Icon(
                painter = painterResource(id = R.drawable.ic_menu_compass),
                contentDescription = "Logo",
                modifier = Modifier.size(120.dp),
                tint = MaterialTheme.colorScheme.primary
            )
            Spacer(modifier = Modifier.height(16.dp))
            Text(
                text = "Campsite Commander",
                style = MaterialTheme.typography.headlineLarge,
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colorScheme.onPrimaryContainer
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroceryListScreen(
    items: List<GroceryItem>,
    onNavigateToAdd: () -> Unit,
    onDeleteItem: (GroceryItem) -> Unit
) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Grocery List") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = onNavigateToAdd) {
                Icon(Icons.Default.Add, contentDescription = "Add Item")
            }
        }
    ) { innerPadding ->
        if (items.isEmpty()) {
            Box(
                modifier = Modifier
                    .fillMaxSize()
                    .padding(innerPadding),
                contentAlignment = Alignment.Center
            ) {
                Text("No items in list")
            }
        } else {
            LazyColumn(modifier = Modifier
                .padding(innerPadding)
                .fillMaxSize()) {
                items(items) { item ->
                    GroceryListItem(item, onDeleteItem)
                }
            }
        }
    }
}

@Composable
fun GroceryListItem(item: GroceryItem, onDeleteItem: (GroceryItem) -> Unit) {
    Card(modifier = Modifier
        .fillMaxWidth()
        .padding(8.dp)) {
        Row(
            modifier = Modifier
                .padding(16.dp)
                .fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = item.name, style = MaterialTheme.typography.titleLarge)
                Text(
                    text = "Category: ${item.category}",
                    style = MaterialTheme.typography.bodyMedium
                )
            }
            IconButton(onClick = { onDeleteItem(item) }) {
                Icon(Icons.Default.Delete, contentDescription = "Delete")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddGroceryScreen(
    categories: Array<String>,
    onAddItem: (String, String) -> Unit,
    onBack: () -> Unit
) {
    var itemName by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(categories[0]) }
    var expanded by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Add New Item") }) }
    ) { innerPadding ->
        Column(
            modifier = Modifier
                .padding(innerPadding)
                .padding(16.dp)
                .fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = itemName,
                onValueChange = { itemName = it },
                label = { Text("Item Name") },
                modifier = Modifier.fillMaxWidth()
            )

            Box {
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Category: $selectedCategory")
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    for (category in categories) {
                        DropdownMenuItem(
                            text = { Text(category) },
                            onClick = {
                                selectedCategory = category
                                expanded = false
                            }
                        )
                    }
                }
            }

            Row(
                modifier = Modifier.fillMaxWidth(),
                horizontalArrangement = Arrangement.SpaceBetween
            ) {
                Button(onClick = onBack) { Text("Cancel") }
                Button(
                    onClick = { if (itemName.isNotBlank()) onAddItem(itemName, selectedCategory) },
                    enabled = itemName.isNotBlank()
                ) {
                    Text("Add Item")
                }
            }
        }
    }
}