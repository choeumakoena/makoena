package com.example.campasitecommander

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material.icons.Icons
import androidx.compose.material.icons.filled.Add
import androidx.compose.material.icons.filled.Delete
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.navigation.NavHostController
import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import com.example.campasitecommander.ui.theme.CampasiteCommanderTheme

// Data model for Grocery Item
data class GroceryItem(val id: Int, val name: String, val category: String)

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        setContent {
            CampasiteCommanderTheme {
                GroceryApp()
            }
        }
    }
}

@Composable
fun GroceryApp() {
    val navController = rememberNavController()
    // Using a mutable list to manage items (arrays are fixed size, so lists are preferred for adding)
    val groceryItems = remember { mutableStateListOf<GroceryItem>() }
    // Requirement: Use of Arrays (Categories)
    val categories = arrayOf("Produce", "Dairy", "Bakery", "Frozen", "Other")

    NavHost(navController = navController, startDestination = "list") {
        composable("list") {
            GroceryListScreen(
                items = groceryItems,
                onNavigateToAdd = { navController.navigate("add") },
                onDeleteItem = { item -> groceryItems.remove(item) }
            )
        }
        composable("add") {
            AddGroceryScreen(
                categories = categories,
                onAddItem = { name, category ->
                    val newItem = GroceryItem(id = groceryItems.size, name = name, category = category)
                    groceryItems.add(newItem)
                    navController.popBackStack()
                },
                onBack = { navController.popBackStack() }
            )
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun GroceryListScreen(
    items: List<GroceryItem>,
    onNavigateToAdd: () -> Unit,
    onDeleteItem: (GroceryItem) -> Unit
) {
    Scaffold(
        topBar = { TopAppBar(title = { Text("Grocery List") }) },
        floatingActionButton = {
            FloatingActionButton(onClick = onNavigateToAdd) {
                Icon(Icons.Default.Add, contentDescription = "Add Item")
            }
        }
    ) { innerPadding ->
        if (items.isEmpty()) {
            Box(modifier = Modifier.fillMaxSize().padding(innerPadding), contentAlignment = Alignment.Center) {
                Text("No items in list")
            }
        } else {
            // Requirement: Loops (LazyColumn uses loops internally, but we can show explicit organization)
            LazyColumn(modifier = Modifier.padding(innerPadding).fillMaxSize()) {
                items(items) { item ->
                    GroceryListItem(item, onDeleteItem)
                }
            }
        }
    }
}

@Composable
fun GroceryListItem(item: GroceryItem, onDeleteItem: (GroceryItem) -> Unit) {
    Card(modifier = Modifier.fillMaxWidth().padding(8.dp)) {
        Row(
            modifier = Modifier.padding(16.dp).fillMaxWidth(),
            horizontalArrangement = Arrangement.SpaceBetween,
            verticalAlignment = Alignment.CenterVertically
        ) {
            Column {
                Text(text = item.name, style = MaterialTheme.typography.titleLarge)
                Text(text = "Category: ${item.category}", style = MaterialTheme.typography.bodyMedium)
            }
            IconButton(onClick = { onDeleteItem(item) }) {
                Icon(Icons.Default.Delete, contentDescription = "Delete")
            }
        }
    }
}

@OptIn(ExperimentalMaterial3Api::class)
@Composable
fun AddGroceryScreen(
    categories: Array<String>,
    onAddItem: (String, String) -> Unit,
    onBack: () -> Unit
) {
    var itemName by remember { mutableStateOf("") }
    var selectedCategory by remember { mutableStateOf(categories[0]) }
    var expanded by remember { mutableStateOf(false) }

    Scaffold(
        topBar = { TopAppBar(title = { Text("Add New Item") }) }
    ) { innerPadding ->
        Column(
            modifier = Modifier.padding(innerPadding).padding(16.dp).fillMaxSize(),
            verticalArrangement = Arrangement.spacedBy(16.dp)
        ) {
            OutlinedTextField(
                value = itemName,
                onValueChange = { itemName = it },
                label = { Text("Item Name") },
                modifier = Modifier.fillMaxWidth()
            )

            // Category Selection using a "loop" to build the menu from the Array
            Box {
                OutlinedButton(onClick = { expanded = true }, modifier = Modifier.fillMaxWidth()) {
                    Text("Category: $selectedCategory")
                }
                DropdownMenu(expanded = expanded, onDismissRequest = { expanded = false }) {
                    // Requirement: Loop through categories array
                    for (category in categories) {
                        DropdownMenuItem(
                            text = { Text(category) },
                            onClick = {
                                selectedCategory = category
                                expanded = false
                            }
                        )
                    }
                }
            }

            Row(modifier = Modifier.fillMaxWidth(), horizontalArrangement = Arrangement.SpaceBetween) {
                Button(onClick = onBack) { Text("Cancel") }
                Button(
                    onClick = { if (itemName.isNotBlank()) onAddItem(itemName, selectedCategory) },
                    enabled = itemName.isNotBlank()
                ) {
                    Text("Add Item")
                }
            }
        }
    }
}
